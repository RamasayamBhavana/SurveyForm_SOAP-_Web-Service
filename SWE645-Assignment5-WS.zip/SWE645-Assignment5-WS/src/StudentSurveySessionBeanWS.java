
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;


/**
 * This is the DAO class through which we connect to the database and
 * manipulation of the data
 *
 * @author Bhavana Ramasayam
 */

public class StudentSurveySessionBeanWS {

	EntityManager entityManager;

	private void SetEntityManager() {
		try {
			entityManager = Persistence.createEntityManagerFactory("bramasay").createEntityManager();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 *
	 * @param studsurveyinfo
	 * @return
	 */
	/*public boolean saveStudentSurveyInfo(StudsurveyinfoWS studsurveyinfo) {
		SetEntityManager();
		try {
			persist(studsurveyinfo);
			System.out.println(studsurveyinfo.getAddComm());
		} catch (Exception excp) {
			excp.printStackTrace();
			return false;
		}
		return true;
	}
	
	public List<StudsurveyinfoWS> retrieveStudentSurveyInfo() {
		SetEntityManager();
		TypedQuery<StudsurveyinfoWS> studentListQuery = entityManager.createNamedQuery("StudsurveyinfoWS.findAll",
				StudsurveyinfoWS.class);
		return studentListQuery.getResultList();
	}
	*/
	public List<StudsurveyinfoWS> searchStudentSurveyInfo(StudsurveyinfoWS studsurveyinfo) {
		SetEntityManager();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();

		CriteriaQuery<StudsurveyinfoWS> criteria = builder.createQuery(StudsurveyinfoWS.class);

		Root<StudsurveyinfoWS> student = criteria.from(StudsurveyinfoWS.class);

		List<Predicate> predicates = new ArrayList<Predicate>();

		if (studsurveyinfo.getFirstname() != null && !(studsurveyinfo.getFirstname().trim().equals(""))) {
			predicates.add(builder.equal(student.get("firstname"), studsurveyinfo.getFirstname()));
		}

		if (studsurveyinfo.getLastname() != null && !(studsurveyinfo.getLastname().trim().equals(""))) {
			predicates.add(builder.equal(student.get("lastname"), studsurveyinfo.getLastname()));
		}

		if (studsurveyinfo.getCity() != null && !(studsurveyinfo.getCity().trim().equals(""))) {
			predicates.add(builder.equal(student.get("city"), studsurveyinfo.getCity()));
		}
		if (studsurveyinfo.getSstate() != null && !(studsurveyinfo.getSstate().trim().equals(""))) {
			predicates.add(builder.equal(student.get("sstate"), studsurveyinfo.getSstate()));
		}

		
		criteria.select(student).where(predicates.toArray(new Predicate[] {}));
		System.out.println(entityManager.createQuery(criteria).getResultList());
		return entityManager.createQuery(criteria).getResultList();
//		List<StudsurveyinfoWS> studs= (List<StudsurveyinfoWS>)entityManager.createQuery(criteria).getResultList();
//		return studs;
		

		/*
		 * Query query = entityManager.createQuery(
		 * "SELECT s from Studsurveyinfo s WHERE s.firstname LIKE :first_name AND s.lastname LIKE :last_name AND s.sstate LIKE :state AND s.city LIKE :city ORDER BY s.lastname ASC"
		 * );
		 * 
		 * String firstName = studsurveyinfo.getFirstname(); String lastName =
		 * studsurveyinfo.getLastname(); String city = studsurveyinfo.getCity();
		 * String state = studsurveyinfo.getSstate();
		 * 
		 * query.setParameter("first_name", firstName);
		 * query.setParameter("last_name", lastName); query.setParameter("city",
		 * city); query.setParameter("state", state);
		 * 
		 * return query.getResultList();
		 */
	}

	public boolean deleteStudentSurveyInfo(int studentId) {
		SetEntityManager();
		try {
			StudsurveyinfoWS studsurveyinfo = entityManager.find(StudsurveyinfoWS.class, studentId);

			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			entityManager.remove(studsurveyinfo);
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
		return true;
	}

	public void persist(Object object) {
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		entityManager.persist(object);
		entityManager.getTransaction().commit();
	}
	
}
