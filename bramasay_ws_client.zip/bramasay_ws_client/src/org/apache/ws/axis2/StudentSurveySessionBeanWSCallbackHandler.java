
/**
 * StudentSurveySessionBeanWSCallbackHandler.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.4  Built on : Oct 21, 2016 (10:47:34 BST)
 */

    package org.apache.ws.axis2;

    /**
     *  StudentSurveySessionBeanWSCallbackHandler Callback class, Users can extend this class and implement
     *  their own receiveResult and receiveError methods.
     */
    public abstract class StudentSurveySessionBeanWSCallbackHandler{



    protected Object clientData;

    /**
    * User can pass in any object that needs to be accessed once the NonBlocking
    * Web service call is finished and appropriate method of this CallBack is called.
    * @param clientData Object mechanism by which the user can pass in user data
    * that will be avilable at the time this callback is called.
    */
    public StudentSurveySessionBeanWSCallbackHandler(Object clientData){
        this.clientData = clientData;
    }

    /**
    * Please use this constructor if you don't want to set any clientData
    */
    public StudentSurveySessionBeanWSCallbackHandler(){
        this.clientData = null;
    }

    /**
     * Get the client data
     */

     public Object getClientData() {
        return clientData;
     }

        
           /**
            * auto generated Axis2 call back method for retrieveStudentSurveyInfo method
            * override this method for handling normal response from retrieveStudentSurveyInfo operation
            */
           public void receiveResultretrieveStudentSurveyInfo(
                    org.apache.ws.axis2.StudentSurveySessionBeanWSStub.RetrieveStudentSurveyInfoResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from retrieveStudentSurveyInfo operation
           */
            public void receiveErrorretrieveStudentSurveyInfo(java.lang.Exception e) {
            }
                
               // No methods generated for meps other than in-out
                
           /**
            * auto generated Axis2 call back method for saveStudentSurveyInfo method
            * override this method for handling normal response from saveStudentSurveyInfo operation
            */
           public void receiveResultsaveStudentSurveyInfo(
                    org.apache.ws.axis2.StudentSurveySessionBeanWSStub.SaveStudentSurveyInfoResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from saveStudentSurveyInfo operation
           */
            public void receiveErrorsaveStudentSurveyInfo(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for searchStudentSurveyInfo method
            * override this method for handling normal response from searchStudentSurveyInfo operation
            */
           public void receiveResultsearchStudentSurveyInfo(
                    org.apache.ws.axis2.StudentSurveySessionBeanWSStub.SearchStudentSurveyInfoResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from searchStudentSurveyInfo operation
           */
            public void receiveErrorsearchStudentSurveyInfo(java.lang.Exception e) {
            }
                
           /**
            * auto generated Axis2 call back method for deleteStudentSurveyInfo method
            * override this method for handling normal response from deleteStudentSurveyInfo operation
            */
           public void receiveResultdeleteStudentSurveyInfo(
                    org.apache.ws.axis2.StudentSurveySessionBeanWSStub.DeleteStudentSurveyInfoResponse result
                        ) {
           }

          /**
           * auto generated Axis2 Error handler
           * override this method for handling error response from deleteStudentSurveyInfo operation
           */
            public void receiveErrordeleteStudentSurveyInfo(java.lang.Exception e) {
            }
                


    }
    