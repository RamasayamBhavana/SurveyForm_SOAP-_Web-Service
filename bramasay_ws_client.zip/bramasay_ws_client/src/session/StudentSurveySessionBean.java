package session;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import entity.Studsurveyinfo;

/**
 * This is the DAO class through which we connect to the database and
 * manipulation of the data
 *
 * @author Bhavana Ramasayam
 */

public class StudentSurveySessionBean {

	EntityManager entityManager;

	private void SetEntityManager() {
		try {
			entityManager = Persistence.createEntityManagerFactory("bramasay").createEntityManager();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 *
	 * @param studsurveyinfo
	 * @return
	 */
	public boolean saveStudentSurveyInfo(Studsurveyinfo studsurveyinfo) {
		SetEntityManager();
		try {
			persist(studsurveyinfo);
			System.out.println(studsurveyinfo.getAddComm());
		} catch (Exception excp) {
			excp.printStackTrace();
			return false;
		}
		return true;
	}

	public List<Studsurveyinfo> retrieveStudentSurveyInfo() {
		SetEntityManager();
		TypedQuery<Studsurveyinfo> studentListQuery = entityManager.createNamedQuery("Studsurveyinfo.findAll",
				Studsurveyinfo.class);
		return studentListQuery.getResultList();
	}

	public List<Studsurveyinfo> searchStudentSurveyInfo(Studsurveyinfo studsurveyinfo) {
		SetEntityManager();

		CriteriaBuilder builder = entityManager.getCriteriaBuilder();

		CriteriaQuery<Studsurveyinfo> criteria = builder.createQuery(Studsurveyinfo.class);

		Root<Studsurveyinfo> student = criteria.from(Studsurveyinfo.class);

		List<Predicate> predicates = new ArrayList<Predicate>();

		if (studsurveyinfo.getFirstname() != null && !(studsurveyinfo.getFirstname().trim().equals(""))) {
			predicates.add(builder.equal(student.get("firstname"), studsurveyinfo.getFirstname()));
		}

		if (studsurveyinfo.getLastname() != null && !(studsurveyinfo.getLastname().trim().equals(""))) {
			predicates.add(builder.equal(student.get("lastname"), studsurveyinfo.getLastname()));
		}

		if (studsurveyinfo.getCity() != null && !(studsurveyinfo.getCity().trim().equals(""))) {
			predicates.add(builder.equal(student.get("city"), studsurveyinfo.getCity()));
		}
		if (studsurveyinfo.getSstate() != null && !(studsurveyinfo.getSstate().trim().equals(""))) {
			predicates.add(builder.equal(student.get("sstate"), studsurveyinfo.getSstate()));
		}

		criteria.select(student).where(predicates.toArray(new Predicate[] {}));

		return entityManager.createQuery(criteria).getResultList();
		

		/*
		 * Query query = entityManager.createQuery(
		 * "SELECT s from Studsurveyinfo s WHERE s.firstname LIKE :first_name AND s.lastname LIKE :last_name AND s.sstate LIKE :state AND s.city LIKE :city ORDER BY s.lastname ASC"
		 * );
		 * 
		 * String firstName = studsurveyinfo.getFirstname(); String lastName =
		 * studsurveyinfo.getLastname(); String city = studsurveyinfo.getCity();
		 * String state = studsurveyinfo.getSstate();
		 * 
		 * query.setParameter("first_name", firstName);
		 * query.setParameter("last_name", lastName); query.setParameter("city",
		 * city); query.setParameter("state", state);
		 * 
		 * return query.getResultList();
		 */
	}

	public boolean deleteStudentSurveyInfo(int studentId) {
		SetEntityManager();
		try {
			Studsurveyinfo studsurveyinfo = entityManager.find(Studsurveyinfo.class, studentId);

			EntityTransaction transaction = entityManager.getTransaction();
			transaction.begin();
			entityManager.remove(studsurveyinfo);
			entityManager.getTransaction().commit();
		} catch (Exception ex) {
			ex.printStackTrace();
			return false;
		}
		return true;
	}

	public void persist(Object object) {
		EntityTransaction transaction = entityManager.getTransaction();
		transaction.begin();
		entityManager.persist(object);
		entityManager.getTransaction().commit();
	}
}
